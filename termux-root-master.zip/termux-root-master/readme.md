<p align="center"><img src="https://e.top4top.io/p_16596l3ql0.jpg">
<a href="https://github.com/safazz"><img alt="Version" src="https://img.shields.io/badge/Version-1-brightgreen"/></a>
<a href="https://github.com/safazz"><img alt="Language" src="https://img.shields.io/badge/Language-Bash-brightgreen"/></a>
</br>
<a href="https://github.com/safazz"><img alt="dependencies" src="https://img.shields.io/badge/Dependencies-proot-lightgrey"/></a>
<a href="https://youtube.com/aslanz"><img alt="Youtube" src="https://img.shields.io/badge/Youtube-ASLANZ-orange"/></a>
<a href="https://instagram.com/aslanz17"><img alt="Instagram" src="https://img.shields.io/badge/Instagram-aslanz17-orange"/></a>
<img src="https://l.top4top.io/p_1659wh63v0.png" width="640" title="root" alt="root"><p>
Coded by <a href="https://github.com/aslanzz">Aslanzz</a>
</p>

## Installation
```
$ apt install git
$ git clone https://github.com/safazz/termux-root
```
## usage
```
$ cd termux-root
$ chmod +x setup
$ ./setup
$ root --help
```

